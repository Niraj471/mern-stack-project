const express = require("express");
const bodyParser = require("body-parser");
const  render  = require("ejs");

var app = express();
app.set("view engine", "ejs");
app.use(express.static("public"));
app.use(bodyParser.urlencoded({ extended: true }));
var items = [];
app.get("/", function (req, res) {
    res.render("list",{ejes:items});
});

app.post("/",function(req,res){
    var item = req.body.ele1;
    items.push(item);
    res.redirect("/");
})

app.listen(8000, function () {
    console.log("Server started on port 8000");
});
