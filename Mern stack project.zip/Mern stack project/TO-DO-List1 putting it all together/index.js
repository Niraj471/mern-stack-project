const express = require("express");
const bodyParser = require("body-parser");
const mongoose = require("mongoose");

var app = express();
app.set("view engine", "ejs");
app.use(express.urlencoded({ extended: true }));
app.use(express.static('public'));

mongoose.connect("mongodb://localhost:27017/todo", { useNewUrlParser: true, useUnifiedTopology: true });

const trySchema = new mongoose.Schema({
    name: String
});

const Item = mongoose.model("Task", trySchema);
const todo1 = new Item({
    name: "learn dsa"
});
const todo2 = new Item({
    name: "learn react"
});
const todo3 = new Item({
    name: "take some rest"
});


app.get("/", async function(req, res) {
    try {
        const foundItems = await Item.find({});
        res.render("list", { dayej: foundItems });
    } catch (err) {
        console.log(err);
    }
});

app.post("/",function(req,res){
    const itemName = req.body.ele1;
    const todo4 = new Item({
        name:itemName
    });
    todo4.save();
    res.redirect("/");
});

app.post("/delete", async function(req, res) {
    const checked = req.body.checkbox1;
    try {
        const deleteItems = await Item.findByIdAndDelete(checked);
        console.log("Item deleted");
    } catch (err) {
        console.log(err);
    }
    res.redirect("/");
});


app.listen(3000, function () {
    console.log("Server started on port 3000");
});
